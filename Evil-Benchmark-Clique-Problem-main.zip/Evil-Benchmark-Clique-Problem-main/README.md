# Evil-Benchmark-Clique-Problem
This is a temporary repository for the Evil Benchmark Clique Problem


The Benchmark has been created by Szabó Sándor, and Bogdán Zaválnij in "Benchmark problems for exhaustive exact maximum clique search algorithms." Informatica 43.2 (2019).
Because the link on the paper does not work, we decided to create this  temporary repository for the Evil Benchmark Clique Problem, to help solvers to download the instances.

